package com.wstutorial.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsdlFirstApp {
    public static void main(String[] args) {
        SpringApplication.run(WsdlFirstApp.class, args);
    }
}